import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import GroupBooking from "./pages/GroupBooking";
import IndividualBooking from "./pages/IndividualBooking";
import BookingQuery from "./pages/BookingQuery";
import CaseQuery from "./pages/CaseQuery";
import AdminDashboard from "./pages/AdminDashboard";
import Traffic from "./pages/Traffic";
import MealDeliveryAdmin from "./pages/MealDeliveryAdmin";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/booking/group" component={GroupBooking} />
      <Route path="/booking/individual" component={IndividualBooking} />
      <Route path="/booking/query" component={BookingQuery} />
      <Route path="/case/query" component={CaseQuery} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/traffic" component={Traffic} />
      <Route path="/meal-delivery" component={MealDeliveryAdmin} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
