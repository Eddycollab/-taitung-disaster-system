import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";

// 管理員專用 procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: '需要管理員權限' });
  }
  return next({ ctx });
});

// 志工專用 procedure（志工和管理員都可使用）
const volunteerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'volunteer' && ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: '需要志工或管理員權限' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============ 使用者管理 ============
  users: router({
    getAll: adminProcedure.query(async () => {
      return await db.getAllUsers();
    }),
    
    updateRole: adminProcedure
      .input(z.object({
        userId: z.number(),
        role: z.enum(["user", "volunteer", "admin"])
      }))
      .mutation(async ({ input }) => {
        await db.updateUserRole(input.userId, input.role);
        return { success: true };
      }),
  }),

  // ============ 志工管理 ============
  volunteers: router({
    create: adminProcedure
      .input(z.object({
        userId: z.number(),
        employeeId: z.string().optional(),
        department: z.string().optional(),
        position: z.string().optional(),
        skills: z.string().optional(),
        availability: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createVolunteer(input);
        await db.updateUserRole(input.userId, "volunteer");
        return { success: true };
      }),

    getAll: adminProcedure.query(async () => {
      return await db.getAllVolunteers();
    }),

    getMyProfile: volunteerProcedure.query(async ({ ctx }) => {
      return await db.getVolunteerByUserId(ctx.user.id);
    }),
  }),

  // ============ 預約管理 ============
  bookings: router({
    create: publicProcedure
      .input(z.object({
        type: z.enum(["group", "individual"]),
        contactName: z.string(),
        contactPhone: z.string(),
        contactEmail: z.string().optional(),
        organizationName: z.string().optional(),
        numberOfPeople: z.number(),
        visitDate: z.date(),
        visitTime: z.string(),
        purpose: z.string().optional(),
        specialNeeds: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const bookingNumber = `BK${Date.now()}`;
        await db.createBooking({
          ...input,
          bookingNumber,
          userId: ctx.user?.id,
          status: "pending"
        });
        return { success: true, bookingNumber };
      }),

    getAll: adminProcedure.query(async () => {
      return await db.getAllBookings();
    }),

    getByNumber: publicProcedure
      .input(z.object({ bookingNumber: z.string() }))
      .query(async ({ input }) => {
        return await db.getBookingByNumber(input.bookingNumber);
      }),

    getByDateRange: adminProcedure
      .input(z.object({
        startDate: z.date(),
        endDate: z.date()
      }))
      .query(async ({ input }) => {
        return await db.getBookingsByDateRange(input.startDate, input.endDate);
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "cancelled", "completed"])
      }))
      .mutation(async ({ input }) => {
        await db.updateBookingStatus(input.id, input.status);
        return { success: true };
      }),

    assignVolunteer: adminProcedure
      .input(z.object({
        bookingId: z.number(),
        volunteerId: z.number()
      }))
      .mutation(async ({ input }) => {
        await db.assignVolunteerToBooking(input.bookingId, input.volunteerId);
        return { success: true };
      }),
  }),

  // ============ 排班管理 ============
  schedules: router({
    create: adminProcedure
      .input(z.object({
        volunteerId: z.number(),
        shiftDate: z.date(),
        shiftTime: z.string(),
        shiftType: z.enum(["morning", "afternoon", "fullday"]),
        bookingId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createSchedule({ ...input, status: "scheduled" });
        return { success: true };
      }),

    getByVolunteer: volunteerProcedure
      .input(z.object({ volunteerId: z.number() }))
      .query(async ({ input }) => {
        return await db.getSchedulesByVolunteer(input.volunteerId);
      }),

    getMySchedules: volunteerProcedure.query(async ({ ctx }) => {
      const volunteer = await db.getVolunteerByUserId(ctx.user.id);
      if (!volunteer) return [];
      return await db.getSchedulesByVolunteer(volunteer.id);
    }),

    getByDateRange: adminProcedure
      .input(z.object({
        startDate: z.date(),
        endDate: z.date()
      }))
      .query(async ({ input }) => {
        return await db.getSchedulesByDateRange(input.startDate, input.endDate);
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["scheduled", "completed", "absent", "leave"])
      }))
      .mutation(async ({ input }) => {
        await db.updateScheduleStatus(input.id, input.status);
        return { success: true };
      }),
  }),

  // ============ 打卡管理 ============
  attendances: router({
    checkIn: volunteerProcedure
      .input(z.object({
        scheduleId: z.number().optional(),
        location: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const volunteer = await db.getVolunteerByUserId(ctx.user.id);
        if (!volunteer) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '找不到志工資料' });
        }
        await db.createAttendance({
          volunteerId: volunteer.id,
          scheduleId: input.scheduleId,
          checkInTime: new Date(),
          location: input.location,
          notes: input.notes,
        });
        return { success: true };
      }),

    checkOut: volunteerProcedure
      .input(z.object({
        attendanceId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const database = await db.getDb();
        if (!database) {
          throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: '資料庫連線失敗' });
        }
        
        const { attendances } = await import('../drizzle/schema');
        const { eq } = await import('drizzle-orm');
        
        const attendance = await database.select().from(attendances)
          .where(eq(attendances.id, input.attendanceId)).limit(1);
        
        if (!attendance || attendance.length === 0) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '找不到打卡記錄' });
        }
        const checkInTime = attendance[0].checkInTime;
        if (!checkInTime) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: '尚未簽到' });
        }
        const checkOutTime = new Date();
        const workHours = Math.floor((checkOutTime.getTime() - checkInTime.getTime()) / 60000);
        await db.checkOut(input.attendanceId, checkOutTime, workHours);
        
        const volunteerId = attendance[0].volunteerId;
        await db.updateVolunteerHours(volunteerId, Math.floor(workHours / 60));
        
        return { success: true, workHours };
      }),

    getMyAttendances: volunteerProcedure.query(async ({ ctx }) => {
      const volunteer = await db.getVolunteerByUserId(ctx.user.id);
      if (!volunteer) return [];
      return await db.getAttendancesByVolunteer(volunteer.id);
    }),
  }),

  // ============ 請假/換班管理 ============
  leaveRequests: router({
    create: volunteerProcedure
      .input(z.object({
        scheduleId: z.number(),
        type: z.enum(["leave", "swap"]),
        targetVolunteerId: z.number().optional(),
        reason: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const volunteer = await db.getVolunteerByUserId(ctx.user.id);
        if (!volunteer) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '找不到志工資料' });
        }
        await db.createLeaveRequest({
          volunteerId: volunteer.id,
          ...input,
          status: "pending"
        });
        return { success: true };
      }),

    getMyRequests: volunteerProcedure.query(async ({ ctx }) => {
      const volunteer = await db.getVolunteerByUserId(ctx.user.id);
      if (!volunteer) return [];
      return await db.getLeaveRequestsByVolunteer(volunteer.id);
    }),

    getPending: adminProcedure.query(async () => {
      return await db.getPendingLeaveRequests();
    }),

    approve: adminProcedure
      .input(z.object({
        id: z.number(),
        reviewNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.updateLeaveRequestStatus(input.id, "approved", ctx.user.id, input.reviewNotes);
        return { success: true };
      }),

    reject: adminProcedure
      .input(z.object({
        id: z.number(),
        reviewNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.updateLeaveRequestStatus(input.id, "rejected", ctx.user.id, input.reviewNotes);
        return { success: true };
      }),
  }),

  // ============ 案件管理 ============
  cases: router({
    create: publicProcedure
      .input(z.object({
        applicantName: z.string(),
        applicantPhone: z.string(),
        applicantEmail: z.string().optional(),
        caseType: z.string(),
        title: z.string(),
        description: z.string(),
        attachments: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const caseNumber = `CS${Date.now()}`;
        await db.createCase({
          ...input,
          caseNumber,
          userId: ctx.user?.id,
          status: "submitted",
          priority: input.priority || "medium"
        });
        return { success: true, caseNumber };
      }),

    getAll: adminProcedure.query(async () => {
      return await db.getAllCases();
    }),

    getByCaseNumber: publicProcedure
      .input(z.object({ caseNumber: z.string() }))
      .query(async ({ input }) => {
        return await db.getCaseByCaseNumber(input.caseNumber);
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["submitted", "reviewing", "processing", "completed", "rejected"])
      }))
      .mutation(async ({ input }) => {
        await db.updateCaseStatus(input.id, input.status);
        return { success: true };
      }),

    assign: adminProcedure
      .input(z.object({
        caseId: z.number(),
        assignedTo: z.number()
      }))
      .mutation(async ({ input }) => {
        await db.assignCaseTo(input.caseId, input.assignedTo);
        return { success: true };
      }),

    addProgress: adminProcedure
      .input(z.object({
        caseId: z.number(),
        step: z.string(),
        description: z.string(),
        status: z.enum(["pending", "in_progress", "completed"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.createCaseProgress({
          ...input,
          updatedBy: ctx.user.id
        });
        return { success: true };
      }),

    getProgress: publicProcedure
      .input(z.object({ caseId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCaseProgressByCaseId(input.caseId);
      }),
  }),

  // ============ 送餐服務管理 ============
  mealDeliveries: router({
    create: adminProcedure
      .input(z.object({
        recipientName: z.string(),
        recipientPhone: z.string(),
        deliveryAddress: z.string(),
        deliveryDate: z.date(),
        deliveryTime: z.string(),
        mealType: z.string().optional(),
        specialInstructions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const deliveryNumber = `MD${Date.now()}`;
        const verificationCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        const qrCode = JSON.stringify({ deliveryNumber, verificationCode });
        
        await db.createMealDelivery({
          ...input,
          deliveryNumber,
          verificationCode,
          qrCode,
          status: "pending"
        });
        return { success: true, deliveryNumber, verificationCode, qrCode };
      }),

    getAll: adminProcedure.query(async () => {
      return await db.getAllMealDeliveries();
    }),

    getMyDeliveries: volunteerProcedure.query(async ({ ctx }) => {
      const volunteer = await db.getVolunteerByUserId(ctx.user.id);
      if (!volunteer) return [];
      return await db.getMealDeliveriesByVolunteer(volunteer.id);
    }),

    assignVolunteer: adminProcedure
      .input(z.object({
        deliveryId: z.number(),
        volunteerId: z.number()
      }))
      .mutation(async ({ input }) => {
        await db.assignVolunteerToDelivery(input.deliveryId, input.volunteerId);
        return { success: true };
      }),

    start: volunteerProcedure
      .input(z.object({ deliveryId: z.number() }))
      .mutation(async ({ input }) => {
        await db.startDelivery(input.deliveryId);
        return { success: true };
      }),

    complete: volunteerProcedure
      .input(z.object({
        deliveryId: z.number(),
        photo: z.string().optional(),
        signature: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.completeDelivery(input.deliveryId, input.photo, input.signature);
        return { success: true };
      }),

    verify: volunteerProcedure
      .input(z.object({
        deliveryId: z.number(),
        verificationCode: z.string()
      }))
      .query(async ({ input }) => {
        const delivery = await db.getMealDeliveryById(input.deliveryId);
        if (!delivery) {
          throw new TRPCError({ code: 'NOT_FOUND', message: '找不到送餐記錄' });
        }
        const isValid = delivery.verificationCode === input.verificationCode;
        return { valid: isValid };
      }),

    addTracking: volunteerProcedure
      .input(z.object({
        deliveryId: z.number(),
        latitude: z.string(),
        longitude: z.string(),
        speed: z.string().optional(),
        accuracy: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createDeliveryTracking({
          ...input,
          timestamp: new Date()
        });
        return { success: true };
      }),

    getTracking: adminProcedure
      .input(z.object({ deliveryId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDeliveryTrackingByDeliveryId(input.deliveryId);
      }),
  }),

  // ============ 通知管理 ============
  notifications: router({
    getMyNotifications: protectedProcedure.query(async ({ ctx }) => {
      return await db.getNotificationsByUser(ctx.user.id);
    }),

    getUnread: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUnreadNotifications(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),

    markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
      await db.markAllNotificationsAsRead(ctx.user.id);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
