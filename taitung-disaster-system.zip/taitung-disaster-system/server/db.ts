import { eq, and, desc, gte, lte, or, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  volunteers, InsertVolunteer,
  bookings, InsertBooking,
  schedules, InsertSchedule,
  attendances, InsertAttendance,
  leaveRequests, InsertLeaveRequest,
  cases, InsertCase,
  caseProgress, InsertCaseProgress,
  mealDeliveries, InsertMealDelivery,
  deliveryTracking, InsertDeliveryTracking,
  notifications, InsertNotification
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ 使用者相關 ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "phone", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "volunteer" | "admin") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ============ 志工相關 ============

export async function createVolunteer(data: InsertVolunteer) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(volunteers).values(data);
  return result;
}

export async function getVolunteerByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(volunteers).where(eq(volunteers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVolunteerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(volunteers).where(eq(volunteers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllVolunteers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select({
    volunteer: volunteers,
    user: users
  }).from(volunteers).leftJoin(users, eq(volunteers.userId, users.id)).orderBy(desc(volunteers.createdAt));
}

export async function updateVolunteerHours(volunteerId: number, additionalHours: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(volunteers)
    .set({ totalHours: sql`${volunteers.totalHours} + ${additionalHours}` })
    .where(eq(volunteers.id, volunteerId));
}

// ============ 預約相關 ============

export async function createBooking(data: InsertBooking) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(bookings).values(data);
  // Return the created booking by bookingNumber
  if (data.bookingNumber) {
    return await getBookingByNumber(data.bookingNumber);
  }
  return null;
}

export async function getBookingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getBookingByNumber(bookingNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookings).where(eq(bookings.bookingNumber, bookingNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllBookings() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(bookings).orderBy(desc(bookings.createdAt));
}

export async function getBookingsByDateRange(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(bookings)
    .where(and(gte(bookings.visitDate, startDate), lte(bookings.visitDate, endDate)))
    .orderBy(bookings.visitDate);
}

export async function updateBookingStatus(id: number, status: "pending" | "confirmed" | "cancelled" | "completed") {
  const db = await getDb();
  if (!db) return;
  await db.update(bookings).set({ status }).where(eq(bookings.id, id));
}

export async function assignVolunteerToBooking(bookingId: number, volunteerId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(bookings).set({ assignedVolunteerId: volunteerId }).where(eq(bookings.id, bookingId));
}

// ============ 排班相關 ============

export async function createSchedule(data: InsertSchedule) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(schedules).values(data);
  return result;
}

export async function getSchedulesByVolunteer(volunteerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(schedules)
    .where(eq(schedules.volunteerId, volunteerId))
    .orderBy(desc(schedules.shiftDate));
}

export async function getSchedulesByDateRange(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  return await db.select({
    schedule: schedules,
    volunteer: volunteers,
    user: users
  }).from(schedules)
    .leftJoin(volunteers, eq(schedules.volunteerId, volunteers.id))
    .leftJoin(users, eq(volunteers.userId, users.id))
    .where(and(gte(schedules.shiftDate, startDate), lte(schedules.shiftDate, endDate)))
    .orderBy(schedules.shiftDate);
}

export async function updateScheduleStatus(id: number, status: "scheduled" | "completed" | "absent" | "leave") {
  const db = await getDb();
  if (!db) return;
  await db.update(schedules).set({ status }).where(eq(schedules.id, id));
}

// ============ 打卡相關 ============

export async function createAttendance(data: InsertAttendance) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(attendances).values(data);
  return result;
}

export async function getAttendancesByVolunteer(volunteerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(attendances)
    .where(eq(attendances.volunteerId, volunteerId))
    .orderBy(desc(attendances.createdAt));
}

export async function checkOut(attendanceId: number, checkOutTime: Date, workHours: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(attendances)
    .set({ checkOutTime, workHours })
    .where(eq(attendances.id, attendanceId));
}

// ============ 請假/換班相關 ============

export async function createLeaveRequest(data: InsertLeaveRequest) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(leaveRequests).values(data);
  return result;
}

export async function getLeaveRequestsByVolunteer(volunteerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(leaveRequests)
    .where(eq(leaveRequests.volunteerId, volunteerId))
    .orderBy(desc(leaveRequests.createdAt));
}

export async function getPendingLeaveRequests() {
  const db = await getDb();
  if (!db) return [];
  return await db.select({
    request: leaveRequests,
    volunteer: volunteers,
    user: users
  }).from(leaveRequests)
    .leftJoin(volunteers, eq(leaveRequests.volunteerId, volunteers.id))
    .leftJoin(users, eq(volunteers.userId, users.id))
    .where(eq(leaveRequests.status, "pending"))
    .orderBy(desc(leaveRequests.createdAt));
}

export async function updateLeaveRequestStatus(
  id: number, 
  status: "pending" | "approved" | "rejected",
  reviewedBy: number,
  reviewNotes?: string
) {
  const db = await getDb();
  if (!db) return;
  await db.update(leaveRequests)
    .set({ status, reviewedBy, reviewedAt: new Date(), reviewNotes })
    .where(eq(leaveRequests.id, id));
}

// ============ 案件相關 ============

export async function createCase(data: InsertCase) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(cases).values(data);
  return result;
}

export async function getCaseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cases).where(eq(cases.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCaseByCaseNumber(caseNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cases).where(eq(cases.caseNumber, caseNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllCases() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(cases).orderBy(desc(cases.createdAt));
}

export async function updateCaseStatus(id: number, status: "submitted" | "reviewing" | "processing" | "completed" | "rejected") {
  const db = await getDb();
  if (!db) return;
  await db.update(cases).set({ status }).where(eq(cases.id, id));
}

export async function assignCaseTo(caseId: number, assignedTo: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(cases).set({ assignedTo }).where(eq(cases.id, caseId));
}

// ============ 案件進度相關 ============

export async function createCaseProgress(data: InsertCaseProgress) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(caseProgress).values(data);
  return result;
}

export async function getCaseProgressByCaseId(caseId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(caseProgress)
    .where(eq(caseProgress.caseId, caseId))
    .orderBy(desc(caseProgress.createdAt));
}

// ============ 送餐相關 ============

export async function createMealDelivery(data: InsertMealDelivery) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(mealDeliveries).values(data);
  return result;
}

export async function getMealDeliveryById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(mealDeliveries).where(eq(mealDeliveries.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMealDeliveriesByVolunteer(volunteerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(mealDeliveries)
    .where(eq(mealDeliveries.volunteerId, volunteerId))
    .orderBy(desc(mealDeliveries.createdAt));
}

export async function getAllMealDeliveries() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(mealDeliveries).orderBy(desc(mealDeliveries.createdAt));
}

export async function updateMealDeliveryStatus(id: number, status: "pending" | "assigned" | "in_transit" | "delivered" | "cancelled") {
  const db = await getDb();
  if (!db) return;
  await db.update(mealDeliveries).set({ status }).where(eq(mealDeliveries.id, id));
}

export async function assignVolunteerToDelivery(deliveryId: number, volunteerId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(mealDeliveries).set({ volunteerId, status: "assigned" }).where(eq(mealDeliveries.id, deliveryId));
}

export async function startDelivery(deliveryId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(mealDeliveries)
    .set({ status: "in_transit", startTime: new Date() })
    .where(eq(mealDeliveries.id, deliveryId));
}

export async function completeDelivery(deliveryId: number, photo?: string, signature?: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(mealDeliveries)
    .set({ 
      status: "delivered", 
      deliveredTime: new Date(),
      photo,
      recipientSignature: signature
    })
    .where(eq(mealDeliveries.id, deliveryId));
}

// ============ 路徑追蹤相關 ============

export async function createDeliveryTracking(data: InsertDeliveryTracking) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(deliveryTracking).values(data);
  return result;
}

export async function getDeliveryTrackingByDeliveryId(deliveryId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(deliveryTracking)
    .where(eq(deliveryTracking.deliveryId, deliveryId))
    .orderBy(deliveryTracking.timestamp);
}

// ============ 通知相關 ============

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(notifications).values(data);
  return result;
}

export async function getNotificationsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function getUnreadNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications)
    .set({ isRead: true, readAt: new Date() })
    .where(eq(notifications.id, id));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications)
    .set({ isRead: true, readAt: new Date() })
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
}
